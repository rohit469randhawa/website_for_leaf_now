Interactive Website for plant enthusiasts. This webiste is made with html,css,php for an internship project by TEAM GAMBIT in association with compsoft technologies.
